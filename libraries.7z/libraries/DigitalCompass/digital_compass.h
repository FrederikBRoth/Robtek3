#ifndef DIGITAL_COMPASS_H
#define DIGITAL_COMPASS_H
#include <Arduino.h>
void getRotationContinuous(float *yaw, float *pitch, float *roll);
void getRotationSingle(float *yaw, float *pitch, float *roll);
void startMPU();
#endif